declare const styles: {
    app: string;
    top: string;
};
export default styles;
//# sourceMappingURL=HideElements.module.scss.d.ts.map