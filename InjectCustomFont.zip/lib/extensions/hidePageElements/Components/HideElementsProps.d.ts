export interface IHideElementsProps {
    Context: any;
}
export interface IHideElementsState {
}
//# sourceMappingURL=HideElementsProps.d.ts.map