import * as React from "react";
import { IHideElementsProps, IHideElementsState } from "./HideElementsProps";
import styles from "./HideElements.module.scss";
import { SiteGroup, sp } from "@pnp/sp/presets/all";
//import {sp} from '@pnp/sp';
import { SPHttpClient } from "@microsoft/sp-http";
import "@pnp/sp/site-groups";

export default class ManageUserInfo extends React.Component<
  IHideElementsProps,
  IHideElementsState
> {
  constructor(props: IHideElementsProps) {
    super(props);
    this.state = {};
  }

  public componentDidMount(): void {
    //Hide Command bar
    /*setTimeout(function () {
      var isHidElementsLen12 =
        document.getElementsByClassName("commandBarWrapper").length;
      if (isHidElementsLen12 > 0) {
        var hidElements12: any =
          document.getElementsByClassName("commandBarWrapper");
        for (var i = 0; i < hidElements12.length; i++) {
          hidElements12[i].style.display = "none";
        }
      }
    }, 5000);*/

    /*sp.web.currentUser.groups.get().then((r: any) => {
      let grpNames: string = "";
      r.forEach((grp: any) => {
        console.log(grp["Title"]);
        if (grp["Title"] == "Content Authors") {
          //Show Command bar
          setTimeout(function () {
            var isHidElementsLen12 =
              document.getElementsByClassName("commandBarWrapper").length;
            if (isHidElementsLen12 > 0) {
              var hidElements12: any =
                document.getElementsByClassName("commandBarWrapper");
              for (var i = 0; i < hidElements12.length; i++) {
                hidElements12[i].style.display = "block";
              }
            }
          }, 5000);
        }
      });
    });*/
  }

  public render(): React.ReactElement<IHideElementsProps> {
    return (
      <div>
        <div className={styles.app}></div>
      </div>
    );
  }
}
