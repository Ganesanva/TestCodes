export interface IStateEmployeeSlider {
    value: any;
}
//# sourceMappingURL=IStateEmployeeSlider.d.ts.map