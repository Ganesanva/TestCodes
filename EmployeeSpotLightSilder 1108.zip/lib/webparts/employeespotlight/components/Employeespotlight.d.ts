import * as React from "react";
import { IEmployeespotlightProps } from "./IEmployeespotlightProps";
import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface SpotlightDetails {
    userDisplayName: string;
    userEmail: string;
    userProfilePic: string;
    description: string;
    designation?: string;
}
export interface IStateEmployeeSlider {
    value: SpotlightDetails[];
    errMsg: string;
}
export interface ResponceDetails {
    title: string;
    id: string;
}
export default class Employeespotlight extends React.Component<IEmployeespotlightProps, IStateEmployeeSlider> {
    private defaultProfileImageUrl;
    private helper;
    private sliderControl;
    constructor(props: IEmployeespotlightProps, state: IStateEmployeeSlider);
    GetUserData(): void;
    componentDidMount(): void;
    componentDidUpdate(): void;
    render(): React.ReactElement<IEmployeespotlightProps>;
    getData(context: WebPartContext, url: string): Promise<IStateEmployeeSlider>;
}
//# sourceMappingURL=Employeespotlight.d.ts.map