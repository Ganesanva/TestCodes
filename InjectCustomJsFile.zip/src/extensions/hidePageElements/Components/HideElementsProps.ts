export interface IHideElementsProps {
  Context: any;  
}
export interface IHideElementsState {
  
}

