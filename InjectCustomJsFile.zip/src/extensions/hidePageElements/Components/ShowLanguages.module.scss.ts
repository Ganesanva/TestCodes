/* tslint:disable */
require('./ShowLanguages.module.css');
const styles = {
  modalContainer: 'modalContainer_05facd0f',
  modalTermsCondition: 'modalTermsCondition_05facd0f',
  modalTitle: 'modalTitle_05facd0f',
  modalBody: 'modalBody_05facd0f',
  app: 'app_05facd0f',
  top: 'top_05facd0f',
  termsEditPanel: 'termsEditPanel_05facd0f',
  userInfoBtn: 'userInfoBtn_05facd0f',
};

export default styles;
/* tslint:enable */