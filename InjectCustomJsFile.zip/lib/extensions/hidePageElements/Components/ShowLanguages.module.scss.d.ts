declare const styles: {
    modalContainer: string;
    modalTermsCondition: string;
    modalTitle: string;
    modalBody: string;
    app: string;
    top: string;
    termsEditPanel: string;
    userInfoBtn: string;
};
export default styles;
//# sourceMappingURL=ShowLanguages.module.scss.d.ts.map