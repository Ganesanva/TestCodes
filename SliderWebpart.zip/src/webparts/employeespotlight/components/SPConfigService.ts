import {
  SPHttpClient,
  SPHttpClientResponse,
  ISPHttpClientOptions,
} from "@microsoft/sp-http";
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { MSGraphClient } from "@microsoft/sp-http";
import { sp } from "@pnp/sp";


export class SPConfigService {
  siteContext: any;
  constructor(context: any) {
    this.siteContext = context;
  }

  public getData(context: WebPartContext, url: string): Promise<any> {
    var url = `${context.pageContext.web.absoluteUrl}${url}`;
    try {
      return context.spHttpClient
        .get(url, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (e) {
      return e;
    }
  }

  public async getUser() {
    let user = await sp.web.currentUser.get();
  }
}
