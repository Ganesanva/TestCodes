import * as React from "react";
import styles from "./Employeespotlight.module.scss";
import { IEmployeespotlightProps } from "./IEmployeespotlightProps";
import { escape } from "@microsoft/sp-lodash-subset";
import * as $ from "jquery";
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient, SPHttpClientResponse } from "@microsoft/sp-http";
import { SliderHelper } from "./Helper";
import { MSGraphClientV3, GraphRequest } from "@microsoft/sp-http";
import * as MicrosoftGraph from "@microsoft/microsoft-graph-types";
require("./mystyle.css");
import { sp } from "@pnp/sp";

export interface SpotlightDetails {
  userDisplayName: string;
  userEmail: string;
  userProfilePic: string;
  description: string;
  designation?: string;
}

export interface IStateEmployeeSlider {
  value: SpotlightDetails[];
  errMsg: string;
}
var result = [];
export interface ResponceDetails {
  title: string;
  id: string;
}
let itemIndex = 0;
export default class Employeespotlight extends React.Component<
  IEmployeespotlightProps,
  IStateEmployeeSlider
> {
  private defaultProfileImageUrl: string = "/_layouts/15/userphoto.aspx?size=L";
  private helper: SliderHelper = new SliderHelper();
  private sliderControl: any = null;
  constructor(props: IEmployeespotlightProps, state: IStateEmployeeSlider) {
    super(props);
    this.state = {
      value: [],
      errMsg: "",
    };
  }

  public GetUserData() {
    const reactHandler = this;
    let MyListname = "";
    if (this.props.listName != undefined) {
      if (this.props.listName["title"]) {
        MyListname = this.props.listName["title"];
      }
    } else {
      //MyListname = "UserDetails";
      reactHandler.setState({
        errMsg:
          "List is not configured. Please edit the webpart and select a list in the webpart panel.",
      });
      return;
    }

    if (this.props.approachTitle == undefined) {
      reactHandler.setState({
        errMsg:
          "Slider Approach is not configured. Please edit the webpart and select approach in the webpart panel.",
      });
      return;
    }

    let queryUrl = "";
    if (
      this.props.deptColumnVal != undefined &&
      this.props.deptColumnVal != ""
    ) {
      queryUrl = `/_api/web/lists/GetByTitle('${MyListname}')/items?$filter=Department eq '${this.props.deptColumnVal}'&$select=*,ID,DisplayName,Designation,Description,Title,Person/EMail&$expand=Person/Id&$orderby=Id desc`;
    } else {
      queryUrl = `/_api/web/lists/GetByTitle('${MyListname}')/items?$select=*,ID,DisplayName,Designation,Description,Title,Person/EMail&$expand=Person/Id&$orderby=Id desc`;
    }

    this.getData(this.props.context, queryUrl).then((data) => {
      try {
        var totalindex = data.value.length;
        if (totalindex == 0) {
          reactHandler.setState({
            errMsg:
              "No items are available based on filter selection on the webpart panel !! ",
          });
        }
        data.value.forEach((element, myindex) => {
          var email = element["Person"]["EMail"];
          var id = element["ID"];

          this.props.context.msGraphClientFactory
            .getClient("3")
            .then(async (graphclient: MSGraphClientV3) => {
              try {
                let photo = await graphclient
                  .api("/users/" + email + "/photo/$value")
                  .get()
                  .then((blob: Blob): Promise<any> => {
                    return new Promise((resolve) => {
                      const profilePicUrl = URL.createObjectURL(blob);
                      result.push({
                        DisplayName: element["DisplayName"],
                        Designation: element["Designation"],
                        Description: element["Description"],
                        Quarter:
                          element["Quarter"] == undefined
                            ? ""
                            : element["Quarter"],
                        Year:
                          element["Year"] == undefined ? "" : element["Year"],
                        IsBanner:
                          element["IsBanner"] == undefined
                            ? false
                            : element["IsBanner"],
                        userProfilePic: profilePicUrl,
                      });

                      if (totalindex == itemIndex + 1) {
                        reactHandler.setState({ value: result });
                      }
                      itemIndex++;

                      console.log("totak index- " + totalindex);
                      console.log("itemIndex- " + itemIndex);
                      console.log(reactHandler.state.value);
                    });
                  });
              } catch (err) {
                result.push({
                  DisplayName: element["DisplayName"],
                  Designation: element["Designation"],
                  Description: element["Description"],
                  Quarter:
                    element["Quarter"] == undefined ? "" : element["Quarter"],
                  Year: element["Year"] == undefined ? "" : element["Year"],
                  IsBanner:
                    element["IsBanner"] == undefined
                      ? false
                      : element["IsBanner"],
                  userProfilePic:
                    "/_layouts/15/userphoto.aspx?size=L&accountname=" + email,
                });

                if (totalindex == itemIndex + 1) {
                  reactHandler.setState({ value: result });
                }
                itemIndex++;

                console.log("totak index- " + totalindex);
                console.log("itemIndex- " + itemIndex);
                console.log(reactHandler.state.value);
              }
            });
        });
      } catch (err) {
        reactHandler.setState({
          errMsg:
            "Error while retrieving data from the selected list on the webpart property panel. Please see the detailed error log in the browser console !! ",
        });
      }
    });
  }
  componentDidMount(): void {
    this.GetUserData();
  }
  componentDidUpdate(): void {
    var _that = this;
    setTimeout(function () {
      _that.helper.moveSlides();
    }, 5000);

    this.sliderControl = setInterval(this.helper.startAutoPlay, 50 * 1000);
    $(document).on("click", "." + styles.prev, (event) => {
      event.preventDefault(); //prevent default action of <a>
      this.helper.moveSlides(-1);
    });
    $(document).on("click", "." + styles.next, (event) => {
      event.preventDefault(); //prevent default action of <a>
      this.helper.moveSlides(1);
    });

    $(document)
      .on("mouseenter", "." + styles.containers, () => {
        clearInterval(this.sliderControl);
      })
      .on("mouseleave", "." + styles.containers, () => {
        var carouselSpeed: number = 50 * 1000;

        this.sliderControl = setInterval(
          this.helper.startAutoPlay,
          carouselSpeed
        );
      });
  }

  public render(): React.ReactElement<IEmployeespotlightProps> {
    const {
      isDarkTheme,
      environmentMessage,
      hasTeamsContext,
      userDisplayName,
      context,
      listName,
    } = this.props;

    return (
      <div>
        <div className={`${styles.errMsgText}`}>{this.state.errMsg}</div>
        <div>
          {this.state.value.length > 0 &&
            this.props.approachTitle == "Hero Image" && (
              <MyEmpSliderApproach1 bindoutput={this.state.value} />
            )}
          {this.state.value.length > 0 &&
            this.props.approachTitle == "Tile View" && (
              <MyEmpSliderApproach2 bindoutput={this.state.value} />
            )}
          {this.state.value.length > 0 &&
            this.props.approachTitle == "Ally Winner" && (
              <MyEmpSliderApproach3 bindoutput={this.state.value} />
            )}
          {this.state.value.length > 0 &&
            this.props.approachTitle == "Banner" && (
              <MyEmpSliderApproach4 bindoutput={this.state.value} />
            )}
        </div>
      </div>
    );
  }

  public getData(
    context: WebPartContext,
    url: string
  ): Promise<IStateEmployeeSlider> {
    var url = `${context.pageContext.web.absoluteUrl}${url}`;
    try {
      return context.spHttpClient
        .get(url, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (e) {
      return e;
    }
  }
}
const MyEmpSliderApproach1 = (props) => {
  //var abc= (document.getElementById("textBox2") as HTMLInputElement).value ;
  const Bindvalue = props.bindoutput.map((Outfile, index) => (
    <>
      <div className={`${styles.mySlides}`}>
        <div style={{ width: "100%" }}>
          <div style={{ width: "36%", float: "left", padding: "10% 0" }}>
            <img
              style={{ borderRadius: "50%", width: "134px" }}
              src={Outfile.userProfilePic}
            />
          </div>
          <div style={{ width: "60%", float: "left", textAlign: "left" }}>
            <h5
              style={{
                marginTop: "13px",
                marginBottom: "0px",
                textTransform: "uppercase",
                textAlign: "center",
                fontSize: "17px",
              }}
            >
              {Outfile.DisplayName}
            </h5>
            <h5 style={{ textAlign: "center", fontSize: "14px", margin: 0 }}>
              {Outfile.Designation}
            </h5>
            <p>{Outfile.Description}</p>
          </div>
        </div>
      </div>
    </>
  ));

  return (
    <>
      <div
        className={`${styles.containers}`}
        id="slideshow"
        style={{
          backgroundColor: "#4c0b4c",
          cursor: "pointer",
          width: "100%!important",
          padding: "5px",
          borderRadius: "15px",
          boxShadow: "rgba(0,0,0,0.25) 0 0 20px 0",
          textAlign: "center",
          color: "white",
          fontWeight: "bold",
        }}
      >
        {Bindvalue}
        <a className={`${styles.prev}`}>
          <img
            src={require("./arrow-88-xxl.png")}
            alt="Back"
            width="15"
            height="15"
          />
        </a>
        <a className={`${styles.next}`}>
          <img
            src={require("./arrow-24-xxl.png")}
            alt="Forward"
            width="15"
            height="15"
          />
        </a>
      </div>
    </>
  );
};
const MyEmpSliderApproach2 = (props) => {
  //var abc= (document.getElementById("textBox2") as HTMLInputElement).value ;
  const MySplitedValue = splitArray(props.bindoutput, 2);
  //props.bindoutput.map((Outfile,index) =>
  const myBindvalue = MySplitedValue.map((myarray, index4) => (
    <div className={`${styles.mySlides}`}>
      {myarray.map((myitem, index5) => (
        <div className="team_scroll">
          <ul>
            <li>
              <div>
                <img src={myitem.userProfilePic} width="150" height="150" />
              </div>
              <h2>{myitem.DisplayName}</h2>
              <h3>{myitem.Designation}</h3>
              <a href="#">Learn more</a>
            </li>
          </ul>
        </div>
      ))}
    </div>
  ));

  return (
    <div
      className={`${styles.containers} newcontainer`}
      id="slideshow"
      style={{
        backgroundColor: "#edebe9",
        cursor: "pointer",
        width: "100%!important",
        borderRadius: "15px",
        boxShadow: "rgba(0,0,0,0.25) 0 0 20px 0",
        textAlign: "center",
        color: "white",
        fontWeight: "bold",
      }}
    >
      <div className="meet_the_team">
        {myBindvalue}
        <a className={`${styles.prev}`}>
          <img
            src={require("./arrow-88-xxl.png")}
            alt="Back"
            width="15"
            height="15"
          />
        </a>
        <a className={`${styles.next}`}>
          <img
            src={require("./arrow-24-xxl.png")}
            alt="Forward"
            width="15"
            height="15"
          />
        </a>
      </div>{" "}
    </div>
  );
};
const MyEmpSliderApproach3 = (props) => {
  //var abc= (document.getElementById("textBox2") as HTMLInputElement).value ;
  const Bindvalue = props.bindoutput.map((Outfile, index) => (
    <>
      <div className={`${styles.mySlides}`}>
        <div className="testimonials">
          <div
            style={{
              textAlign: "left",
              paddingLeft: "5px",
              fontSize: "16px",
              color: "#422341",
            }}
          >
            I'm an Ally Winners
          </div>
          <div className="testimonials_sec">
            <div className="testi_img">
              <img src={Outfile.userProfilePic} width="150" height="150" />
            </div>
            <div className="testi_cont">
              <p>{Outfile.Description}</p>
              <p>
                <span style={{ fontSize: "16px" }}>
                  - {Outfile.DisplayName}
                </span>
                <span>&nbsp;&nbsp;</span>
                <span style={{ fontSize: "16px" }}>{Outfile.Designation}</span>
                {Outfile.Quarter != "" ? (
                  <span>
                    <span style={{ fontSize: "16px" }}>
                      ,&nbsp;{Outfile.Quarter}
                    </span>
                    <span>&nbsp;</span>
                    <span style={{ fontSize: "16px" }}>{Outfile.Year}</span>
                  </span>
                ) : (
                  ""
                )}
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  ));

  return (
    <>
      <div
        className={`${styles.containers}`}
        id="slideshow"
        style={{
          cursor: "pointer",
          width: "100%!important",
          padding: "0px",
          borderRadius: "15px",
          textAlign: "center",
          color: "white",
          fontWeight: "bold",
        }}
      >
        {Bindvalue}
        <a className={`${styles.prev}`}>
          <img
            src={require("./arrow-88-xxl.png")}
            alt="Back"
            width="15"
            height="15"
          />
        </a>
        <a className={`${styles.next}`}>
          <img
            src={require("./arrow-24-xxl.png")}
            alt="Forward"
            width="15"
            height="15"
          />
        </a>
      </div>
    </>
  );
};
const MyEmpSliderApproach4 = (props) => {
  //var abc= (document.getElementById("textBox2") as HTMLInputElement).value ;
  const Bindvalue = props.bindoutput.map((Outfile, index) => (
    <>
      {Outfile.IsBanner == true ? (
        <div className={`${styles.bannerContainer}`}>
          <div style={{ padding: "10px" }}>
            <div className="bannerContent">
              <div className="bannerContent_sec">
                <div className="bannerContent_img">
                  <img src={Outfile.userProfilePic} width="150" height="150" />
                </div>
                <div className="bannerContent_cont">
                  <p>{Outfile.Description}</p>
                  <p>
                    <span style={{ fontSize: "16px" }}>
                      - {Outfile.DisplayName}
                    </span>
                    <span>&nbsp;&nbsp;</span>
                    <span style={{ fontSize: "16px" }}>
                      {Outfile.Designation}
                    </span>
                    {Outfile.Quarter != "" ? (
                      <span>
                        <span style={{ fontSize: "16px" }}>
                          ,&nbsp;{Outfile.Quarter}
                        </span>
                        <span>&nbsp;</span>
                        <span style={{ fontSize: "16px" }}>{Outfile.Year}</span>
                      </span>
                    ) : (
                      ""
                    )}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
    </>
  ));

  return (
    <>
      <div
        className={`${styles.containers}`}
        id="slideshow"
        style={{
          backgroundColor: "midnightblue",
          cursor: "pointer",
          width: "100%!important",
          padding: "5px",
          borderRadius: "15px",
          boxShadow: "rgba(0,0,0,0.25) 0 0 20px 0",
          textAlign: "center",
          color: "white",
          fontWeight: "bold",
        }}
      >
        {Bindvalue}
      </div>
    </>
  );
};
const splitArray = (array, chunk_size) => {
  const output = [];
  const arrayCopy = [...array];
  while (arrayCopy.length > 0) {
    output.push(arrayCopy.splice(0, chunk_size));
  }
  return output;
};
