export declare class SliderHelper {
    static slideIndex: number;
    constructor();
    /**
     * auto play slider
     */
    startAutoPlay(): void;
    /**
     * move slide
     * @param n - slide index.
     */
    moveSlides(n?: number): boolean;
}
//# sourceMappingURL=Helper.d.ts.map