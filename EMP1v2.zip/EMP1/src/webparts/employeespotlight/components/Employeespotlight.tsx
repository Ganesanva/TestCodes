import * as React from 'react';
import styles from './Employeespotlight.module.scss';
import { IEmployeespotlightProps } from './IEmployeespotlightProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as $ from 'jquery'; 
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { SliderHelper } from './Helper';
require('./mystyle.css');
export interface SpotlightDetails {
  userDisplayName: string;
  userEmail: string;
  userProfilePic: string;
  description: string;
  designation?: string;
}

export interface IStateEmployeeSlider {
  value:SpotlightDetails[];
  
  }
  var result=[];
export interface ResponceDetails {
  title: string;
  id: string;
}
export default class Employeespotlight extends React.Component<IEmployeespotlightProps, IStateEmployeeSlider> {
  private defaultProfileImageUrl: string = "/_layouts/15/userphoto.aspx?size=L";
  private helper: SliderHelper = new SliderHelper();
  private sliderControl: any = null;
  constructor(props: IEmployeespotlightProps, state: IStateEmployeeSlider) {
    super(props);
    this.state = {
      
      value: []
      

    };

  }

  public GetUserData(){

    let MyListname="";
    if (this.props.lists != undefined) {
      if (this.props.lists['title']) {
        MyListname = this.props.lists['title']
      }
    }
else
MyListname='UserDetails';
    let url = `/_api/web/lists/GetByTitle('${MyListname}')/items?$select=ID,DisplayName,Designation,Description,Title,UserPickerData/EMail&$expand=UserPickerData/Id&$orderby=Id desc`;

    this.getData(this.props.context, url).then((data) => {
var totalindex=data.value.length;
      data.value.forEach((element,myindex) => {  
        var email = element["UserPickerData"]["EMail"];
      var id = element["ID"];
      let userImage = "/_api/SP.UserProfiles.PeopleManager/GetPropertiesFor(accountName=@v)?@v='i:0%23.f|membership|" + email + "'";
      this.getData(this.props.context, userImage).then((response) => {
       
        var displayName = response["DisplayName"];
      // uses default image if user image not exist 
      var profilePicture = response["PictureUrl"] != null && response["PictureUrl"] != undefined ? (response["PictureUrl"]).replace("MThumb", "LThumb") : this.defaultProfileImageUrl;
      profilePicture = '/_layouts/15/userphoto.aspx?accountname=' + displayName + '&size=M&url=' + profilePicture.split("?")[0];
      result.push({ 
        DisplayName: element["DisplayName"],
        Designation:element["Designation"],
        Description: element["Description"],
        userProfilePic: profilePicture

      });
      if(totalindex==myindex+1){
      this.setState({ value: result });  }
    });
       
      }); 
      
    });

  }
  componentDidMount(): void {
    this.GetUserData()
  }
  componentDidUpdate(): void {
    var _that=this;
    setTimeout(function(){
      _that.helper.moveSlides()
  }, 5000);
 
    
 this.sliderControl = setInterval(this.helper.startAutoPlay, 50 * 1000);
                      $(document).on("click", "." + styles.prev, (event) => {
                        event.preventDefault();    //prevent default action of <a>
                        this.helper.moveSlides(-1);
                      });
                      $(document).on("click", "." + styles.next, (event) => {
                        event.preventDefault();    //prevent default action of <a>
                        this.helper.moveSlides(1);
                      });
                      
                        $(document).on('mouseenter', '.' + styles.containers, () => {
                          
                            clearInterval(this.sliderControl);
                        }).on('mouseleave', '.' + styles.containers, () => {
                          var carouselSpeed: number = 50 * 1000;
                        
                          this.sliderControl = setInterval(this.helper.startAutoPlay, carouselSpeed);
                      });
  }

  
  public render(): React.ReactElement<IEmployeespotlightProps> {
    const {
      
      isDarkTheme,
      environmentMessage,
      hasTeamsContext,
      userDisplayName,context,lists
    } = this.props;

    return (
  
      <div >
      <div >
      { this.state.value.length>0 && this.props.DropDownValue=='Approach1' &&<MyEmpSliderApproach1 bindoutput={this.state.value} />}        
      { this.state.value.length>0 && this.props.DropDownValue=='Approach2' &&<MyEmpSliderApproach2 bindoutput={this.state.value} />}        
      { this.state.value.length>0 && this.props.DropDownValue=='Approach3' &&<MyEmpSliderApproach3 bindoutput={this.state.value} />}        
       
     </div>
     
        </div>
    
 
    );
  }
   
  public  getData(context: WebPartContext, url: string): Promise<IStateEmployeeSlider> {
    var url = `${context.pageContext.web.absoluteUrl}${url}`
    try {
      return   context.spHttpClient.get(url, SPHttpClient.configurations.v1).then((response: SPHttpClientResponse) => {
        return response.json();
      });
    }
    catch (e) {
      return e;
    }
  }
}
const MyEmpSliderApproach1 = (props) => {    
  //var abc= (document.getElementById("textBox2") as HTMLInputElement).value ;    
  const Bindvalue = props.bindoutput.map((Outfile,index) =>  
  <> 
<div className={`${styles.mySlides}`}>
                    <div style={{width:'100%'}}>
                          <div style={{width:'36%',float:'left',padding:'10% 0'}}>
                            <img style={{borderRadius:'50%',width: '90px'}} src={Outfile.userProfilePic} />
                          </div>
                          <div style={{width:'60%',float:'left',textAlign:'left' }}>
                              <h5 style={{marginBottom:'0', textTransform: 'uppercase',textAlign:'center'}}>{Outfile.DisplayName}</h5>
                              <h5 style={{textAlign:'center'}}>{Outfile.Designation}</h5>
                              <p>{Outfile.Description}</p>                              
                          </div>
                      </div>
                  </div>
                  </> 
    
 );    
 
  return (    
<>  
<div className={`${styles.containers}`} id="slideshow" style={{backgroundColor: '#4c0b4c', cursor:'pointer',width: "100%!important",padding: "5px",borderRadius: '15px',boxShadow: 'rgba(0,0,0,0.25) 0 0 20px 0','textAlign':'center',color:'white' ,fontWeight:'bold'}}>
      {Bindvalue}
      <a  className={`${styles.prev}`}><img src={require('./arrow-88-xxl.png')} alt="Back" width="10" height="10"/></a>
       <a  className={`${styles.next}`}><img src={require('./arrow-24-xxl.png')} alt="Forward" width="10" height="10"/></a>
       </div>
      </>  
       
   
  );    
 };  
 const MyEmpSliderApproach2 = (props) => {    
  //var abc= (document.getElementById("textBox2") as HTMLInputElement).value ;   
  const MySplitedValue = splitArray(props.bindoutput, 2); 
  //props.bindoutput.map((Outfile,index) =>  
const myBindvalue=MySplitedValue.map((myarray,index4) => 
  
  <div className={`${styles.mySlides}`} >
      {myarray.map((myitem,index5) => (
         <div className="team_scroll">
         <ul>
             <li>
                 <div ><img src={myitem.userProfilePic} width="150" height="150"/></div>
                   <h2>{myitem.DisplayName}</h2>
                   <h3>{myitem.Designation}</h3>
                   <a href="#">Learn more</a>
               </li>
               
           </ul>
          
       </div>
      ))}
   </div>

)
 
 
  return (    

<div className={`${styles.containers} newcontainer`} id="slideshow" style={{backgroundColor: '#edebe9', cursor:'pointer',width: "100%!important",borderRadius: '15px',boxShadow: 'rgba(0,0,0,0.25) 0 0 20px 0','textAlign':'center',color:'white' ,fontWeight:'bold'}}>
<div className="meet_the_team">
{myBindvalue}
      <a  className={`${styles.prev}`}><img src={require('./arrow-88-xxl.png')} alt="Back" width="10" height="10"/></a>
       <a  className={`${styles.next}`}><img src={require('./arrow-24-xxl.png')} alt="Forward" width="10" height="10"/></a>
       </div> </div>
       
       
   
  );    
 };  
 const MyEmpSliderApproach3 = (props) => {    
  //var abc= (document.getElementById("textBox2") as HTMLInputElement).value ;    
  const Bindvalue = props.bindoutput.map((Outfile,index) =>  
  <> 
<div className={`${styles.mySlides}`}>
<div className="testimonials">
    	<h1>{Outfile.DisplayName}</h1>
        
        <div className="testimonials_sec">
            <div className="testi_img"><img src={Outfile.userProfilePic} width="150" height="150"  /></div>
            <div className="testi_cont">
            	<p>{Outfile.Description}</p>
                <p><span>{Outfile.Designation}</span></p>
            </div>

        </div>
    </div>
                  </div>
                  </> 
    
 );    
 
  return (    
<>  
<div className={`${styles.containers}`} id="slideshow" style={{ cursor:'pointer',width: "100%!important",padding: "5px",borderRadius: '15px','textAlign':'center',color:'white' ,fontWeight:'bold'}}>
      {Bindvalue}
      <a  className={`${styles.prev}`}><img src={require('./arrow-88-xxl.png')} alt="Back" width="10" height="10"/></a>
       <a  className={`${styles.next}`}><img src={require('./arrow-24-xxl.png')} alt="Forward" width="10" height="10"/></a>
       </div>
      </>  
       
   
  );    
 };  
 const splitArray = (array, chunk_size) => {
  const output = [];
  const arrayCopy = [...array];
  while (arrayCopy.length > 0) {
    output.push(arrayCopy.splice(0, chunk_size));
  }
  return output;
};