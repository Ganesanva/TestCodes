export interface IStateEmployeeSlider {
value:any;

}