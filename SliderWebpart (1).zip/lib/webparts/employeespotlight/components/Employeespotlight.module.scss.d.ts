declare const styles: {
    employeespotlight: string;
    teams: string;
    containers: string;
    mySlides: string;
    slideIn: string;
    welcome: string;
    welcomeImage: string;
    links: string;
    prev: string;
    next: string;
    errMsgText: string;
    bannerContainer: string;
    bannerBottomLeft: string;
};
export default styles;
//# sourceMappingURL=Employeespotlight.module.scss.d.ts.map