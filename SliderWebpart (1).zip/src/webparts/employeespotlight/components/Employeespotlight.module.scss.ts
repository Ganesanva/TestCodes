/* tslint:disable */
require("./Employeespotlight.module.css");
const styles = {
  employeespotlight: 'employeespotlight_17c1479e',
  teams: 'teams_17c1479e',
  containers: 'containers_17c1479e',
  mySlides: 'mySlides_17c1479e',
  slideIn: 'slideIn_17c1479e',
  welcome: 'welcome_17c1479e',
  welcomeImage: 'welcomeImage_17c1479e',
  links: 'links_17c1479e',
  prev: 'prev_17c1479e',
  next: 'next_17c1479e',
  errMsgText: 'errMsgText_17c1479e',
  bannerContainer: 'bannerContainer_17c1479e',
  bannerBottomLeft: 'bannerBottomLeft_17c1479e'
};

export default styles;
/* tslint:enable */