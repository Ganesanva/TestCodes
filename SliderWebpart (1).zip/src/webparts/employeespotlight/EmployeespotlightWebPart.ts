import * as React from "react";
import * as ReactDom from "react-dom";
import { Version } from "@microsoft/sp-core-library";
import { sp } from "@pnp/sp";

/**
 * Detailed list information
 */
export interface IPropertyFieldList {
  /**
   * List ID
   */
  id: string;
  /**
   * List Title
   */
  title?: string;
  /**
   * List server relative URL
   */
  url?: string;
}
import {
  IPropertyPaneConfiguration,
  PropertyPaneDropdown,
} from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";
import { IReadonlyTheme } from "@microsoft/sp-component-base";

import * as strings from "EmployeespotlightWebPartStrings";
import Employeespotlight from "./components/Employeespotlight";
import { IEmployeespotlightProps } from "./components/IEmployeespotlightProps";
import {
  PropertyFieldListPicker,
  PropertyFieldListPickerOrderBy,
} from "@pnp/spfx-property-controls/lib/PropertyFieldListPicker";
import {
  PropertyFieldColumnPicker,
  PropertyFieldColumnPickerOrderBy,
} from "@pnp/spfx-property-controls/lib/PropertyFieldColumnPicker";

export interface IEmployeespotlightWebPartProps {
  lists: string;
  dropdownProperty: string;
  departmentColumn: string;
}

enum IColumnReturnProperty {
  Id = 0,
  Title = 1,
  "Internal Name" = "InternalName",
}
var spObj = null;
let ChoicesCollection: any[] = [];
export default class EmployeespotlightWebPart extends BaseClientSideWebPart<IEmployeespotlightWebPartProps> {
  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = "";

  public render(): void {
    const element: React.ReactElement<IEmployeespotlightProps> =
      React.createElement(Employeespotlight, {
        isDarkTheme: this._isDarkTheme,
        environmentMessage: this._environmentMessage,
        hasTeamsContext: !!this.context.sdks.microsoftTeams,
        userDisplayName: this.context.pageContext.user.displayName,
        context: this.context,
        listName: this.properties.lists,
        approachTitle: this.properties.dropdownProperty,
        deptColumnVal: this.properties.departmentColumn,
      });

    ReactDom.render(element, this.domElement);
  }

  protected onInit(): Promise<void> {
    this._environmentMessage = this._getEnvironmentMessage();
    sp.setup({
      spfxContext: this.context,
    });
    spObj = sp;

    this.getDepartmentFieldChoices();

    return super.onInit();
  }

  public async getDepartmentFieldChoices() {
    //Clear collection
    ChoicesCollection = [];
    let deptListName = "";
    if (this.properties.lists != undefined) {
      if (this.properties.lists["title"]) {
        deptListName = this.properties.lists["title"];
      }

      let deptFieldList = sp.web.lists.getByTitle(deptListName);
      let deptField =
        deptFieldList.fields.getByInternalNameOrTitle("Department");
      deptField
        .select("Choices")
        .get()
        .then((deptData) => {
          console.log(deptData);

          deptData.Choices.map((item) => {
            ChoicesCollection.push({
              key: item,
              text: item,
            });
          });

          this.context.propertyPane.refresh();
          if (!this.disableReactivePropertyChanges) {
            //this.render();
          }
        });
    }
  }

  private _getEnvironmentMessage(): string {
    if (!!this.context.sdks.microsoftTeams) {
      // running in Teams
      return this.context.isServedFromLocalhost
        ? strings.AppLocalEnvironmentTeams
        : strings.AppTeamsTabEnvironment;
    }

    return this.context.isServedFromLocalhost
      ? strings.AppLocalEnvironmentSharePoint
      : strings.AppSharePointEnvironment;
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }

    this._isDarkTheme = !!currentTheme.isInverted;
    const { semanticColors } = currentTheme;

    if (semanticColors) {
      this.domElement.style.setProperty(
        "--bodyText",
        semanticColors.bodyText || null
      );
      this.domElement.style.setProperty("--link", semanticColors.link || null);
      this.domElement.style.setProperty(
        "--linkHovered",
        semanticColors.linkHovered || null
      );
    }
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse("1.0");
  }

  protected onPropertyPaneFieldChanged(
    propertyPath: string,
    oldValue: any,
    newValue: any
  ): void {
    if (newValue !== oldValue && propertyPath === "lists") {
      this.getDepartmentFieldChoices();
    }
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription,
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyFieldListPicker("lists", {
                  label: "Select a list",
                  includeListTitleAndUrl: true,
                  selectedList: this.properties.lists,
                  includeHidden: false,
                  orderBy: PropertyFieldListPickerOrderBy.Title,
                  disabled: false,
                  onPropertyChange: this.onPropertyPaneFieldChanged.bind(this),
                  properties: this.properties,
                  context: this.context as any,
                  onGetErrorMessage: null,
                  baseTemplate: 100,
                  deferredValidationTime: 0,
                  key: "listPickerFieldId",
                }),
                PropertyPaneDropdown("dropdownProperty", {
                  label: "Select Approach",
                  disabled: false,

                  options: [
                    { key: "Hero Image", text: "Hero Image" },
                    { key: "Tile View", text: "Tile View" },
                    { key: "Ally Winner", text: "Ally Winner" },
                    { key: "Banner", text: "Banner" },
                  ],
                }),
                PropertyPaneDropdown("departmentColumn", {
                  label: "Select user department",
                  disabled: false,

                  options: ChoicesCollection,
                }),
              ],
            },
          ],
        },
      ],
    };
  }
}
