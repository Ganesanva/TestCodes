/* tslint:disable */
require("./HideElements.module.css");
const styles = {
  app: 'app_80d3e1f4',
  top: 'top_80d3e1f4'
};

export default styles;
/* tslint:enable */