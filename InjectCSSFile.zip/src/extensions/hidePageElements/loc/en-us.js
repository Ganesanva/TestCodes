define([], function() {
  return {
    "Title": "HidePageElementsApplicationCustomizer"
  }
});