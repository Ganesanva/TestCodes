declare interface IHidePageElementsApplicationCustomizerStrings {
  Title: string;
}

declare module 'HidePageElementsApplicationCustomizerStrings' {
  const strings: IHidePageElementsApplicationCustomizerStrings;
  export = strings;
}
