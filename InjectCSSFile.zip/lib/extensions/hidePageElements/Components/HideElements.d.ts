import * as React from "react";
import { IHideElementsProps, IHideElementsState } from "./HideElementsProps";
import "@pnp/sp/site-groups";
export default class ManageUserInfo extends React.Component<IHideElementsProps, IHideElementsState> {
    constructor(props: IHideElementsProps);
    componentDidMount(): void;
    render(): React.ReactElement<IHideElementsProps>;
}
//# sourceMappingURL=HideElements.d.ts.map