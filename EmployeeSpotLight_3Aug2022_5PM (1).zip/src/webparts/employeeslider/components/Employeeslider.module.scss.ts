/* tslint:disable */
require("./Employeeslider.module.css");
const styles = {
  employeeslider: 'employeeslider_bb2ccad0',
  teams: 'teams_bb2ccad0',
  divWidth: 'divWidth_bb2ccad0',
  topdivborder: 'topdivborder_bb2ccad0',
  bodyouterwidth: 'bodyouterwidth_bb2ccad0',
  h5border: 'h5border_bb2ccad0',
  h6border: 'h6border_bb2ccad0',
  containers: 'containers_bb2ccad0',
  welcome: 'welcome_bb2ccad0',
  welcomeImage: 'welcomeImage_bb2ccad0',
  links: 'links_bb2ccad0'
};

export default styles;
/* tslint:enable */