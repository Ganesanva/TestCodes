export interface IStateEmployeeSlider {
value:any;
DisplayName:string;
Description:string;
userProfilePic:string;
Designation:string;
}