import * as React from "react";
import styles from "./Employeeslider.module.scss";
import { IEmployeesliderProps } from "./IEmployeesliderProps";
import { IStateEmployeeSlider } from "./IStateEmployeeSlider";
import { escape } from "@microsoft/sp-lodash-subset";
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient, SPHttpClientResponse } from "@microsoft/sp-http";
import { MSGraphClient } from "@microsoft/sp-http";
import { SPConfigService } from "./SPConfigService";
import { spfi } from "@pnp/sp";
import "@pnp/sp/profiles";
import { graphfi, DefaultInit } from "@pnp/graph";
import "@pnp/graph/users";
import "@pnp/graph/photos";

export interface SpotlightDetails {
  userDisplayName: string;
  userEmail: string;
  userProfilePic: string;
  description: string;
  designation?: string;
}
export interface ResponceCollection {
  value: ResponceDetails[];
}
export interface ResponceDetails {
  title: string;
  id: string;
}
export default class Employeeslider extends React.Component<
  IEmployeesliderProps,
  IStateEmployeeSlider
> {
  sp_Service: SPConfigService;
  constructor(props: IEmployeesliderProps, state: IStateEmployeeSlider) {
    super(props);

    this.sp_Service = new SPConfigService(this.props.context);
    this.state = {
      Description: "",
      DisplayName: "",
      value: [],
      userProfilePic: "",
      Designation: "",
    };
  }

  componentDidMount() {
    const reactHandler = this;
    let url = `/_api/web/lists/GetByTitle('UserDetails')/items?$select=ID,DisplayName,Designation,Description,Title,UserPickerData/EMail&$expand=UserPickerData/Id&$orderby=Id desc`;
    this.sp_Service.getData(this.props.context, url).then((data) => {
      var email = data.value[0]["UserPickerData"]["EMail"];
      //var id = data.value[0]["ID"];

      /*.header(
        "Authorization",
        `Bearer ${sessionStorage.getItem("accesstoken")}`
      )*/
      this.props.context.msGraphClientFactory
        .getClient()
        .then(async (graphclient: MSGraphClient) => {
          try {
            let photo = await graphclient
              .api("/users/" + email + "/photo/$value")
              .responseType("blob")
              .get()
              .then((blob: Blob): Promise<any> => {
                return new Promise((resolve) => {
                  const profilePicUrl = URL.createObjectURL(blob);

                  this.setState({
                    DisplayName: data.value[0].DisplayName,
                    Designation: data.value[0].Designation,
                    Description: data.value[0].Description,
                    userProfilePic: profilePicUrl,
                  });
                });
              });
          } catch (err) {
            this.setState({
              DisplayName: data.value[0].DisplayName,
              Designation: data.value[0].Designation,
              Description: data.value[0].Description,
              userProfilePic:
                "/_layouts/15/userphoto.aspx?size=L&accountname=" + email,
            });
          }
        });
    });
  }

  public render(): React.ReactElement<IEmployeesliderProps> {
    return (
      <div className={styles.containers}>
        <div className={styles.divWidth}>
          <div className={styles.topdivborder}>
            <img src={this.state.userProfilePic} width={"200"} height={"200"} />
          </div>
          <div className={styles.bodyouterwidth}>
            <h5 className={styles.h5border}>{this.state.DisplayName}</h5>
            <h6 className={styles.h6border}>{this.state.Designation}</h6>
            <p>{this.state.Description}</p>
          </div>
        </div>
      </div>
    );
  }
}
