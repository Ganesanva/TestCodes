export interface IEmployeesliderProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    context: any;
}
//# sourceMappingURL=IEmployeesliderProps.d.ts.map