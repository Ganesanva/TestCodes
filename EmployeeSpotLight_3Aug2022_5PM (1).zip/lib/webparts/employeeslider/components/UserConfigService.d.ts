import { WebPartContext } from "@microsoft/sp-webpart-base";
import "@pnp/polyfill-ie11";
export declare class UserConfigService {
    siteContext: any;
    constructor(context: any);
    getData(context: WebPartContext, url: string): Promise<any>;
}
//# sourceMappingURL=UserConfigService.d.ts.map