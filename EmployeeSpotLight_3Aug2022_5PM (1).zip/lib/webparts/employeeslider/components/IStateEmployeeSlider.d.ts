export interface IStateEmployeeSlider {
    value: any;
    DisplayName: string;
    Description: string;
    userProfilePic: string;
    Designation: string;
}
//# sourceMappingURL=IStateEmployeeSlider.d.ts.map