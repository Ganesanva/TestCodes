declare const styles: {
    employeeslider: string;
    teams: string;
    divWidth: string;
    topdivborder: string;
    bodyouterwidth: string;
    h5border: string;
    h6border: string;
    containers: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=Employeeslider.module.scss.d.ts.map