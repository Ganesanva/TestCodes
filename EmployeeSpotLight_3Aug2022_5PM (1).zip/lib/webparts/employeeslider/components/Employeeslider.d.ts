import * as React from "react";
import { IEmployeesliderProps } from "./IEmployeesliderProps";
import { IStateEmployeeSlider } from "./IStateEmployeeSlider";
import { SPConfigService } from "./SPConfigService";
import "@pnp/sp/profiles";
import "@pnp/graph/users";
import "@pnp/graph/photos";
export interface SpotlightDetails {
    userDisplayName: string;
    userEmail: string;
    userProfilePic: string;
    description: string;
    designation?: string;
}
export interface ResponceCollection {
    value: ResponceDetails[];
}
export interface ResponceDetails {
    title: string;
    id: string;
}
export default class Employeeslider extends React.Component<IEmployeesliderProps, IStateEmployeeSlider> {
    sp_Service: SPConfigService;
    constructor(props: IEmployeesliderProps, state: IStateEmployeeSlider);
    componentDidMount(): void;
    render(): React.ReactElement<IEmployeesliderProps>;
}
//# sourceMappingURL=Employeeslider.d.ts.map