/* tslint:disable */
require("./Employeespotlight.module.css");
const styles = {
  employeespotlight: 'employeespotlight_6128793a',
  teams: 'teams_6128793a',
  containers: 'containers_6128793a',
  mySlides: 'mySlides_6128793a',
  slideIn: 'slideIn_6128793a',
  welcome: 'welcome_6128793a',
  welcomeImage: 'welcomeImage_6128793a',
  links: 'links_6128793a',
  prev: 'prev_6128793a',
  next: 'next_6128793a'
};

export default styles;
/* tslint:enable */