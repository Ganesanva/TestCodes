import * as React from 'react';
import styles from './Employeespotlight.module.scss';
import { IEmployeespotlightProps } from './IEmployeespotlightProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as $ from 'jquery'; 
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { SliderHelper } from './Helper';
export interface SpotlightDetails {
  userDisplayName: string;
  userEmail: string;
  userProfilePic: string;
  description: string;
  designation?: string;
}

export interface IStateEmployeeSlider {
  value:SpotlightDetails[];
  
  }
  var result=[];
export interface ResponceDetails {
  title: string;
  id: string;
}
export default class Employeespotlight extends React.Component<IEmployeespotlightProps, IStateEmployeeSlider> {
  private defaultProfileImageUrl: string = "/_layouts/15/userphoto.aspx?size=L";
  private helper: SliderHelper = new SliderHelper();
  private sliderControl: any = null;
  constructor(props: IEmployeespotlightProps, state: IStateEmployeeSlider) {
    super(props);
    this.state = {
      
      value: []
      

    };

  }

  public GetUserData(){
    let url = `/_api/web/lists/GetByTitle('UserDetails')/items?$select=ID,DisplayName,Designation,Description,Title,UserPickerData/EMail&$expand=UserPickerData/Id&$orderby=Id desc`;

    this.getData(this.props.context, url).then((data) => {

      data.value.forEach(element => {  
        var email = element["UserPickerData"]["EMail"];
      var id = element["ID"];
      let userImage = "/_api/SP.UserProfiles.PeopleManager/GetPropertiesFor(accountName=@v)?@v='i:0%23.f|membership|" + email + "'";
      this.getData(this.props.context, userImage).then((response) => {
       
        var displayName = response["DisplayName"];
      // uses default image if user image not exist 
      var profilePicture = response["PictureUrl"] != null && response["PictureUrl"] != undefined ? (response["PictureUrl"]).replace("MThumb", "LThumb") : this.defaultProfileImageUrl;
      profilePicture = '/_layouts/15/userphoto.aspx?accountname=' + displayName + '&size=M&url=' + profilePicture.split("?")[0];
      result.push({ 
        DisplayName: element["DisplayName"],
        Designation:element["Designation"],
        Description: element["Description"],
        userProfilePic: profilePicture

      });
      this.setState({ value: result });  
    });
       
      }); 
      
    });

  }
  componentDidMount(): void {
    this.GetUserData()
  }
  componentDidUpdate(): void {
    var _that=this;
    setTimeout(function(){
      _that.helper.moveSlides()
  }, 5000);
 
    
 this.sliderControl = setInterval(this.helper.startAutoPlay, 5 * 1000);
                      $(document).on("click", "." + styles.prev, (event) => {
                        event.preventDefault();    //prevent default action of <a>
                        this.helper.moveSlides(-1);
                      });
                      $(document).on("click", "." + styles.next, (event) => {
                        event.preventDefault();    //prevent default action of <a>
                        this.helper.moveSlides(1);
                      });
                      
                        $(document).on('mouseenter', '.' + styles.containers, () => {
                          
                            clearInterval(this.sliderControl);
                        }).on('mouseleave', '.' + styles.containers, () => {
                          var carouselSpeed: number = 5 * 1000;
                        
                          this.sliderControl = setInterval(this.helper.startAutoPlay, carouselSpeed);
                      });
  }

  
  public render(): React.ReactElement<IEmployeespotlightProps> {
    const {
      description,
      isDarkTheme,
      environmentMessage,
      hasTeamsContext,
      userDisplayName
    } = this.props;

    return (
      <div >
      <div >
      <div className={`${styles.containers}`} id="slideshow" style={{backgroundColor: '#4c0b4c', cursor:'pointer',width: "100%!important",padding: "5px",borderRadius: '15px',boxShadow: 'rgba(0,0,0,0.25) 0 0 20px 0','textAlign':'center',color:'white' ,fontWeight:'bold'}}>
      { this.state.value.length>0 && <MyEmpSlider bindoutput={this.state.value} />}        
       <a  className={`${styles.prev}`}><img src={require('./arrow-88-xxl.png')} alt="Back" width="10" height="10"/></a>
       <a  className={`${styles.next}`}><img src={require('./arrow-24-xxl.png')} alt="Forward" width="10" height="10"/></a>
     </div>
     
        </div>
      
  </div>
    );
  }
   
  public getData(context: WebPartContext, url: string): Promise<IStateEmployeeSlider> {
    var url = `${context.pageContext.web.absoluteUrl}${url}`
    try {
      return context.spHttpClient.get(url, SPHttpClient.configurations.v1).then((response: SPHttpClientResponse) => {
        return response.json();
      });
    }
    catch (e) {
      return e;
    }
  }
}
const MyEmpSlider = (props) => {    
  //var abc= (document.getElementById("textBox2") as HTMLInputElement).value ;    
  const Bindvalue = props.bindoutput.map((Outfile,index) =>  
  <> 
<div className={`${styles.mySlides}`}>
                    <div style={{width:'100%'}}>
                          <div style={{width:'36%',float:'left',padding:'10% 0'}}>
                            <img style={{borderRadius:'50%',width: '90px'}} src={Outfile.userProfilePic} />
                          </div>
                          <div style={{width:'60%',float:'left',textAlign:'left' }}>
                              <h5 style={{marginBottom:'0', textTransform: 'uppercase',textAlign:'center'}}>{Outfile.DisplayName}</h5>
                              <h5 style={{textAlign:'center'}}>{Outfile.Designation}</h5>
                              <p>{Outfile.Description}</p>                              
                          </div>
                      </div>
                  </div>
                  </> 
    
 );    
 
  return (    
<>  
      {Bindvalue}</>  
       
   
  );    
 };  