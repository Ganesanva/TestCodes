/* tslint:disable */
require("./Employeespotlight.module.css");
const styles = {
  employeespotlight: 'employeespotlight_8c4af456',
  teams: 'teams_8c4af456',
  containers: 'containers_8c4af456',
  mySlides: 'mySlides_8c4af456',
  slideIn: 'slideIn_8c4af456',
  welcome: 'welcome_8c4af456',
  welcomeImage: 'welcomeImage_8c4af456',
  links: 'links_8c4af456',
  prev: 'prev_8c4af456',
  next: 'next_8c4af456',
  errMsgText: 'errMsgText_8c4af456'
};

export default styles;
/* tslint:enable */