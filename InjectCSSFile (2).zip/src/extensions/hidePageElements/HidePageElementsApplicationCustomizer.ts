import { override } from "@microsoft/decorators";
import { Log } from "@microsoft/sp-core-library";
import {
  BaseApplicationCustomizer,
  PlaceholderContent,
  PlaceholderName,
} from "@microsoft/sp-application-base";
import { Dialog } from "@microsoft/sp-dialog";
import * as strings from "HidePageElementsApplicationCustomizerStrings";
const LOG_SOURCE: string = "HidePageElementsApplicationCustomizer";
import * as React from "react";
import * as ReactDom from "react-dom";
import { IHideElementsProps } from "./Components/HideElementsProps";
import HideElements from "./Components/HideElements";
import { setup as pnpSetup } from "@pnp/common";
import { sp } from "@pnp/sp";

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IHidePageElementsApplicationCustomizerProperties {
  // This is an example; replace with your own property
  siteUrl: string;
}

/** A Custom Action which can be run during execution of a Client Side Application */
export default class HidePageElementsApplicationCustomizer extends BaseApplicationCustomizer<IHidePageElementsApplicationCustomizerProperties> {
  private _topPlaceholder: PlaceholderContent | undefined;
  @override
  public onInit(): Promise<void> {
    let webUrl = this.context.pageContext.web.absoluteUrl;

    const cssUrl: string = webUrl + "/SiteAssets/Styles/CustomFont.css";
    if (cssUrl) {
      // inject the style sheet
      const head: any =
        document.getElementsByTagName("head")[0] || document.documentElement;
      let customStyle: HTMLLinkElement = document.createElement("link");
      customStyle.href = cssUrl + "?r=" + Math.random();
      customStyle.rel = "stylesheet";
      customStyle.type = "text/css";
      head.insertAdjacentElement("beforeEnd", customStyle);
    }

    // Wait for the placeholders to be created (or handle them being changed) and then
    // render.
    /*this.context.placeholderProvider.changedEvent.add(
     this,
      this.renderPlaceHolders
    );

    pnpSetup({
      spfxContext: this.context
    });*/

    return Promise.resolve();
  }

  private renderPlaceHolders(): void {
    console.log("SiteLanguagesApplicationCustomizer._renderPlaceHolders()");
    console.log(
      "Available placeholders: ",
      this.context.placeholderProvider.placeholderNames
        .map((name) => PlaceholderName[name])
        .join(", ")
    );

    // Handling the top placeholder
    if (!this._topPlaceholder) {
      this._topPlaceholder = this.context.placeholderProvider.tryCreateContent(
        PlaceholderName.Top,
        { onDispose: this._onDispose }
      );

      // The extension should not assume that the expected placeholder is available.
      if (!this._topPlaceholder) {
        console.error("The expected placeholder (Top) was not found.");
        return;
      }

      if (this.properties) {
        if (this._topPlaceholder.domElement) {
          const element: React.ReactElement<IHideElementsProps> =
            React.createElement(HideElements, {
              Context: this.context,
            });
          ReactDom.render(element, this._topPlaceholder.domElement);
        }
      }
    }
  }
  private _onDispose(): void {
    console.log(
      "[SiteLanguagesApplicationCustomizer._onDispose] Disposed custom top and bottom placeholders."
    );
  }
}
