import { Version } from "@microsoft/sp-core-library";
/**
 * Detailed list information
 */
export interface IPropertyFieldList {
    /**
     * List ID
     */
    id: string;
    /**
     * List Title
     */
    title?: string;
    /**
     * List server relative URL
     */
    url?: string;
}
import { IPropertyPaneConfiguration } from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";
import { IReadonlyTheme } from "@microsoft/sp-component-base";
export interface IEmployeespotlightWebPartProps {
    lists: string;
    dropdownProperty: string;
    departmentColumn: string;
}
export default class EmployeespotlightWebPart extends BaseClientSideWebPart<IEmployeespotlightWebPartProps> {
    private _isDarkTheme;
    private _environmentMessage;
    render(): void;
    protected onInit(): Promise<void>;
    getDepartmentFieldChoices(): Promise<void>;
    private _getEnvironmentMessage;
    protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected onPropertyPaneFieldChanged(propertyPath: string, oldValue: any, newValue: any): void;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=EmployeespotlightWebPart.d.ts.map