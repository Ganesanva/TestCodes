import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IEmployeespotlightProps {
    context: WebPartContext;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    listName: string;
    approachTitle: string;
    deptColumnVal: string;
}
//# sourceMappingURL=IEmployeespotlightProps.d.ts.map