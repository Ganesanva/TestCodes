/* tslint:disable */
require("./Employeespotlight.module.css");
const styles = {
  employeespotlight: 'employeespotlight_b5208644',
  teams: 'teams_b5208644',
  containers: 'containers_b5208644',
  mySlides: 'mySlides_b5208644',
  slideIn: 'slideIn_b5208644',
  welcome: 'welcome_b5208644',
  welcomeImage: 'welcomeImage_b5208644',
  links: 'links_b5208644',
  prev: 'prev_b5208644',
  next: 'next_b5208644'
};

export default styles;
/* tslint:enable */