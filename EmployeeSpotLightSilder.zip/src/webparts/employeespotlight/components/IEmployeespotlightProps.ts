import { WebPartContext } from '@microsoft/sp-webpart-base'; 
export interface IEmployeespotlightProps {
  context: WebPartContext;
 
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  lists: string;
  DropDownValue:string;
}
