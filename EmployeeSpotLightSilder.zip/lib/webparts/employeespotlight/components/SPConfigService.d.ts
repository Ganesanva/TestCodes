import { WebPartContext } from "@microsoft/sp-webpart-base";
export declare class SPConfigService {
    siteContext: any;
    constructor(context: any);
    getData(context: WebPartContext, url: string): Promise<any>;
}
//# sourceMappingURL=SPConfigService.d.ts.map